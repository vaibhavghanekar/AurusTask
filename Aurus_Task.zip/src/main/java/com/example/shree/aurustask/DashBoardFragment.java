package com.example.shree.aurustask;


import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.appolica.flubber.Flubber;


/**
 * A simple {@link Fragment} subclass.
 */
public class DashBoardFragment extends AbstarctFragment implements View.OnClickListener {

    View view;
    Button btn_camera, btn_contacts, btn_location;
    TextView tv_task;

    public DashBoardFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_dash_board, container, false);

        tv_task = (TextView) view.findViewById(R.id.tv_task);
        btn_camera = (Button) view.findViewById(R.id.btn_camera);
        btn_contacts = (Button) view.findViewById(R.id.btn_contacts);
        btn_location = (Button) view.findViewById(R.id.btn_location);

        Flubber.with()
                .animation(Flubber.AnimationPreset.SLIDE_DOWN)
                .interpolator(Flubber.Curve.BZR_EASE_IN)
                .duration(1000)
                .autoStart(true)
                .createFor(tv_task);

        animate(Flubber.AnimationPreset.SLIDE_LEFT, 2000, btn_camera);
        animate(Flubber.AnimationPreset.SLIDE_RIGHT, 2000, btn_contacts);
        animate(Flubber.AnimationPreset.SLIDE_LEFT, 2000, btn_location);

        btn_camera.setOnClickListener(this);
        btn_contacts.setOnClickListener(this);
        btn_location.setOnClickListener(this);

        return view;
    }

    private void animate(Flubber.AnimationPreset effect, int time, Button component) {
        Flubber.with()
                .animation(effect)
                .interpolator(Flubber.Curve.BZR_EASE_IN)
                .duration(time)
                .autoStart(true)
                .createFor(component);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {

            case R.id.btn_camera:
                //
                CameraFragment cameraFragment = new CameraFragment();
                fragmentReplace(cameraFragment, "camera", R.id.rl_dashboard_activity, true);
                break;

            case R.id.btn_contacts:
                //
                ContactFragment contactFragment = new ContactFragment();
                fragmentReplace(contactFragment, "contact", R.id.rl_dashboard_activity, true);
                break;

            case R.id.btn_location:
                //
                Intent intent = new Intent(getActivity(), MapsActivity.class);
                startActivity(intent);
                break;
        }
    }
}
