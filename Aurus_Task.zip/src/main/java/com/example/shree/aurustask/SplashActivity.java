package com.example.shree.aurustask;

import android.content.Intent;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import com.appolica.flubber.Flubber;

public class SplashActivity extends AppCompatActivity {

    TextView tv_task;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tv_task = (TextView) findViewById(R.id.tv_task);

        Flubber.with()
                .animation(Flubber.AnimationPreset.SLIDE_DOWN)
                .interpolator(Flubber.Curve.BZR_EASE_IN)
                .duration(1000)
                .autoStart(true)
                .createFor(tv_task);

        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent intent = new Intent(SplashActivity.this, LoginActivity.class);
                startActivity(intent);
                finish();
            }
        }, 3000);
    }
}
