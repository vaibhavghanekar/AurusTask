package com.example.shree.aurustask;

import android.app.FragmentManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Toast;

import com.github.euzee.permission.PermissionCallback;
import com.github.euzee.permission.PermissionUtil;

public class DashBoardActivity extends AbstarctActivity {

    private NetworkAvailability networkAvailability;
    NetworkBroadcastReceiver broadcastReceiver;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dash_board);

        broadcastReceiver = new NetworkBroadcastReceiver();

        networkAvailability = NetworkAvailability.getInstance();
        networkAvailability.registerNetworkAvailability(this, broadcastReceiver);

        checkPermissions();

        DashBoardFragment dashBoardFragment = new DashBoardFragment();
        fragmentAdd(dashBoardFragment, "dashboard", R.id.rl_dashboard_activity);
    }

    /*private BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent.getBooleanExtra(ConnectivityManager.EXTRA_NO_CONNECTIVITY, false)) {
                Toast.makeText(context, "network is not available", Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(context, "network is available", Toast.LENGTH_LONG).show();
            }
        }
    };*/

    private void checkPermissions() {
        PermissionUtil.checkGroup(DashBoardActivity.this, new PermissionCallback() {
            @Override
            public void onPermissionGranted() {
                //Toast.makeText(DashBoardActivity.this, "Permissions Granted", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onPermissionDenied() {
                //Toast.makeText(DashBoardActivity.this, "Permissions Denied", Toast.LENGTH_SHORT).show();
            }
        }, new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION,
                android.Manifest.permission.CAMERA,
                android.Manifest.permission.ACCESS_NETWORK_STATE,
                android.Manifest.permission.ACCESS_COARSE_LOCATION,
                android.Manifest.permission.WRITE_EXTERNAL_STORAGE,
                android.Manifest.permission.READ_CONTACTS,
                android.Manifest.permission.WRITE_CONTACTS});
    }
}
