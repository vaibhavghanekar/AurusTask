package com.example.shree.aurustask;


import android.content.Context;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.github.euzee.permission.PermissionCallback;
import com.github.euzee.permission.PermissionUtil;

import java.util.ArrayList;
import java.util.Collections;

/**
 * A simple {@link Fragment} subclass.
 */
public class ContactFragment extends Fragment {

    ListView listView;
    ArrayList<ContactsModel> StoreContacts;
    CustomAdapter<ContactsModel> customAdapter;
    Cursor cursor;
    String name, phonenumber;
    Button button;
    View view;

    public ContactFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_contact, container, false);

        listView = (ListView) view.findViewById(R.id.listview1);
        button = (Button) view.findViewById(R.id.button1);

        StoreContacts = new ArrayList<ContactsModel>();

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkPermissions();
            }
        });


        return view;
    }

    private void checkPermissions() {
        PermissionUtil.checkGroup(getActivity(), new PermissionCallback() {
            @Override
            public void onPermissionGranted() {//This is actually permission denied
                Toast.makeText(getActivity(), "Permissions Denied", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onPermissionDenied() {//This is actually permission granted
                GetContactsIntoArrayList();

                customAdapter = new CustomAdapter<ContactsModel>(getActivity(), StoreContacts);
                listView.setAdapter(customAdapter);
                listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                        DialogFragment_ContactsDetails dialogFragment_contactsDetails = new DialogFragment_ContactsDetails();
                        Bundle bundle = new Bundle();
                        bundle.putParcelable("contact", StoreContacts.get(i));
                        dialogFragment_contactsDetails.setArguments(bundle);
                        dialogFragment_contactsDetails.show(getFragmentManager(), "contact");
                    }
                });
            }
        }, new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION,
                android.Manifest.permission.CAMERA,
                android.Manifest.permission.ACCESS_NETWORK_STATE,
                android.Manifest.permission.ACCESS_COARSE_LOCATION,
                android.Manifest.permission.WRITE_EXTERNAL_STORAGE,
                android.Manifest.permission.READ_CONTACTS,
                android.Manifest.permission.WRITE_CONTACTS});
    }

    private void GetContactsIntoArrayList() {
        cursor = getActivity().getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null, null, null, null);

        while (cursor.moveToNext()) {

            name = cursor.getString(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME));
            phonenumber = cursor.getString(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));

            ContactsModel contactsModel = new ContactsModel(name, phonenumber);
            StoreContacts.add(contactsModel);

            Collections.sort(StoreContacts, new CustomComparator());
        }

        cursor.close();
    }

    private class CustomAdapter<ContactsModel> extends BaseAdapter {

        Context context;
        ArrayList<ContactsModel> storeContacts;

        public CustomAdapter(Context context, ArrayList<ContactsModel> storeContacts) {
            this.context = context;
            this.storeContacts = storeContacts;
        }

        @Override
        public int getCount() {
            return storeContacts.size();
        }

        @Override
        public Object getItem(int i) {
            return storeContacts.get(i);
        }

        @Override
        public long getItemId(int i) {
            return storeContacts.indexOf(i);
        }

        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {

            class ViewHolder {
                TextView textView;
            }
            ViewHolder viewHolder;

            if (view == null) {
                LayoutInflater layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                view = layoutInflater.inflate(R.layout.lv_contacts_row, null);

                viewHolder = new ViewHolder();
                viewHolder.textView = (TextView) view.findViewById(R.id.textView);
                view.setTag(viewHolder);
            } else {
                viewHolder = (ViewHolder) view.getTag();
            }

            viewHolder.textView.setText(StoreContacts.get(i).getName());
            return view;
        }
    }

    private class CustomComparator implements java.util.Comparator<ContactsModel> {

        @Override
        public int compare(ContactsModel firstModel, ContactsModel secondModel) {
            return firstModel.getName().compareTo(secondModel.getName());
        }
    }
}
