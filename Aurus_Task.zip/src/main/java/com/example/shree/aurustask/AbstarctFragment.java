package com.example.shree.aurustask;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;

public class AbstarctFragment extends Fragment {

    public void fragmentReplace(Fragment fragment, String str, int layout, boolean addbackStack) {
        android.support.v4.app.FragmentManager fragmentManager = getFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(layout, fragment, str);
        if (addbackStack)
            fragmentTransaction.addToBackStack(str);
        fragmentTransaction.commit();
    }
}