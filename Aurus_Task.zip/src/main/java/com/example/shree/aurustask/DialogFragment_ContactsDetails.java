package com.example.shree.aurustask;


import android.os.Bundle;
import android.os.Parcelable;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.Fragment;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;


/**
 * A simple {@link Fragment} subclass.
 */
public class DialogFragment_ContactsDetails extends DialogFragment {

    View view;
    TextView tv_name, tv_number;
    Button btn_close;

    public DialogFragment_ContactsDetails() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_dialog_fragment__contacts_details, container, false);

        tv_name = (TextView) view.findViewById(R.id.tv_name);
        tv_number = (TextView) view.findViewById(R.id.tv_number);
        btn_close = (Button) view.findViewById(R.id.btn_close);

        Bundle bundle = this.getArguments();
        if (null != bundle) {
            ContactsModel contactsModel = bundle.getParcelable("contact");

            String name = contactsModel.getName().replaceAll("\\s+", "");
            if (android.text.TextUtils.isDigitsOnly(name)) {
                tv_name.setText("No Name");
            } else {
                tv_name.setText(contactsModel.getName());
            }
            tv_number.setText(contactsModel.getNumber());
        }

        btn_close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dismiss();
            }
        });
        return view;
    }

}
