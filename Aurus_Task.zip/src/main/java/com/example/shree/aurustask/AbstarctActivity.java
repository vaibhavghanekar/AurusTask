package com.example.shree.aurustask;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;

public class AbstarctActivity extends AppCompatActivity {

    public void fragmentAdd(Fragment fragment, String str, int layout) {
        android.support.v4.app.FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.add(layout, fragment, str);
        fragmentTransaction.commit();
    }

}