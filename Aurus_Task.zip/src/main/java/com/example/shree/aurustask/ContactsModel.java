package com.example.shree.aurustask;

import android.os.Parcel;
import android.os.Parcelable;

public class ContactsModel implements Parcelable {

    private String name;
    private String number;

    public ContactsModel(String name, String number) {
        this.name = name;
        this.number = number;
    }

    protected ContactsModel(Parcel in) {
        name = in.readString();
        number = in.readString();
    }

    public static final Creator<ContactsModel> CREATOR = new Creator<ContactsModel>() {
        @Override
        public ContactsModel createFromParcel(Parcel in) {
            return new ContactsModel(in);
        }

        @Override
        public ContactsModel[] newArray(int size) {
            return new ContactsModel[size];
        }
    };

    @Override
    public String toString() {
        return "ContactsModel{" +
                "name='" + name + '\'' +
                ", number='" + number + '\'' +
                '}';
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(name);
        parcel.writeString(number);
    }
}