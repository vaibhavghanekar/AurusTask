package com.example.shree.aurustask;


import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.github.euzee.permission.PermissionCallback;
import com.github.euzee.permission.PermissionUtil;

import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

import static android.app.Activity.RESULT_CANCELED;
import static android.app.Activity.RESULT_OK;


/**
 * A simple {@link Fragment} subclass.
 */
public class CameraFragment extends AbstarctFragment {

    View view;
    Button btn_click, btn_save;
    ImageView imgv_image;
    EditText ed_height, ed_width;
    Bitmap bitmap;
    private static final int CAPTURE_IAMGE = 100;
    private Uri uri;
    LinearLayout ll_dimension;
    private int permissionflag = 0;

    public CameraFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_camera, container, false);

        btn_click = (Button) view.findViewById(R.id.btn_click);
        imgv_image = (ImageView) view.findViewById(R.id.imgv_image);
        btn_save = (Button) view.findViewById(R.id.btn_save);
        ed_height = (EditText) view.findViewById(R.id.ed_height);
        ed_width = (EditText) view.findViewById(R.id.ed_width);
        ll_dimension = (LinearLayout) view.findViewById(R.id.ll_dimension);

        btn_click.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                permissionflag = 1;
                checkPermissions();
            }
        });

        btn_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                permissionflag = 2;
                checkPermissions();
            }
        });
        return view;
    }

    private void getDimensions() {
        if (ed_height.getText().toString().trim().length() > 0 && ed_width.getText().toString().trim().length() > 0) {

            int height = Integer.parseInt(ed_height.getText().toString().trim());
            int width = Integer.parseInt(ed_width.getText().toString().trim());

            if (height < 1 || width < 1)
                Toast.makeText(getActivity(), "height and width should be positive integers.", Toast.LENGTH_SHORT).show();
            else {
                Bitmap resizedBitmap = Bitmap.createScaledBitmap(
                        bitmap, height, width, false);

                String partFilename = currentDateFormat();
                storeCameraPhotoInSDCard(resizedBitmap, partFilename);
            }

        }

        if (ed_height.getText().toString().trim().length() == 0)
            ed_height.setError("Enter Height");
        if (ed_width.getText().toString().trim().length() == 0)
            ed_width.setError("Enter Width");
    }

    private void checkPermissions() {
        PermissionUtil.checkGroup(getActivity(), new PermissionCallback() {
            @Override
            public void onPermissionGranted() {//This is actually permission denied
                Toast.makeText(getActivity(), "Permissions Denied", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onPermissionDenied() {//This is actually permission granted
                if (permissionflag == 1)
                    captureImage();
                else if (permissionflag == 2)
                    getDimensions();
            }
        }, new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION,
                android.Manifest.permission.CAMERA,
                android.Manifest.permission.ACCESS_NETWORK_STATE,
                android.Manifest.permission.ACCESS_COARSE_LOCATION,
                android.Manifest.permission.WRITE_EXTERNAL_STORAGE,
                android.Manifest.permission.READ_CONTACTS,
                android.Manifest.permission.WRITE_CONTACTS});
    }

    private void captureImage() {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(intent, CAPTURE_IAMGE, null);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == CAPTURE_IAMGE) {
            if (resultCode == RESULT_OK) {
                getImage(data);
            } else if (resultCode == RESULT_CANCELED) {
                Toast.makeText(getActivity(), "Action Cancelled!", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(getActivity(), "Failed to capture image!", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void getImage(Intent data) {
        bitmap = (Bitmap) data.getExtras().get("data");

        imgv_image.setVisibility(View.VISIBLE);
        ll_dimension.setVisibility(View.VISIBLE);
        btn_save.setVisibility(View.VISIBLE);

        imgv_image.setImageBitmap(bitmap);
    }

    private void storeCameraPhotoInSDCard(Bitmap bitmap, String partFilename) {
        File file = new File(Environment.getExternalStorageDirectory(), "photo_" + partFilename + ".jpg");
        try {
            FileOutputStream fileOutputStream = new FileOutputStream(file);
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, fileOutputStream);
            fileOutputStream.flush();
            fileOutputStream.close();

            Toast.makeText(getActivity(), "Image saved in the gallery.", Toast.LENGTH_SHORT).show();
            fragmentReplace(new DashBoardFragment(), "dash", R.id.rl_dashboard_activity, false);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private String currentDateFormat() {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd_HH_mm_ss");
        String currentTimeStamp = dateFormat.format(new Date());
        return currentTimeStamp;
    }

}
