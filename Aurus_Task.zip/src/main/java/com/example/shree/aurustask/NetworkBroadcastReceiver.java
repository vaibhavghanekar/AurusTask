package com.example.shree.aurustask;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.widget.Toast;

public class NetworkBroadcastReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent.getBooleanExtra(ConnectivityManager.EXTRA_NO_CONNECTIVITY, false)) {
            Toast.makeText(context, "network is not available", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(context, "network is available", Toast.LENGTH_SHORT).show();
        }
    }
}

